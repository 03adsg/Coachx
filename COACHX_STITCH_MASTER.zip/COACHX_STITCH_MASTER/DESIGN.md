---
name: COACHX — Master Stitch Design System
version: 1.0
date: 2026-08-08
source: Google Stitch exports consolidated into one package
screens: 33
---

# COACHX — Master Stitch Design System

This is the **single design reference** for the COACHX Stitch package.

All Stitch screens supplied for COACHX so far are consolidated here. Each screen's exported `code.html` and `screen.png` are preserved, while this file unifies the shared visual system and the complete screen inventory.

## Source-of-truth rule

1. **Stitch screen renderings are the visual source of truth.**
2. Each exported `code.html` is the structural/style reference for that screen.
3. This `DESIGN.md` is the shared system reference.
4. Do **not** replace the Stitch visual language with a generic mobile UI kit.
5. Reuse the same components, spacing, typography, icon treatment, cards, controls, navigation, anatomical visuals and interaction patterns.
6. If a screenshot export is unavailable, use its `code.html` as the available Stitch reference and regenerate the screenshot from Stitch when needed.

## Brand & Style

The system is engineered for a high-performance personal training and nutrition environment. The aesthetic is **Dark-Mode Minimalist** with **Tactile Athleticism**: deep black foundation, fluorescent performance accents, strong metric hierarchy, tonal depth instead of decorative shadows, and one-handed gym-ready interaction.

Key characteristics:
- **Athletic Precision:** rigid grids and high-contrast typography.
- **Elite Professionalism:** avoid decorative shadows; use tonal layering.
- **Immediate Feedback:** fluorescent lime drives active, completed and successful states.
- **Gym-ready UX:** large touch targets, fast scanning, clear metrics, minimal friction.
- **iPhone-first:** narrow mobile composition and one-handed use.

## Colors

### COACHX visual palette used across the supplied Stitch screens

- **Deep Black:** `#050505` — primary application background.
- **Primary Lime:** `#B6FF00` — active states, primary actions, completed sets, active muscle groups, success/progression signals.
- **Card Surface:** `#121212` — primary cards and content containers.
- **Elevated Surface:** `#181818` — elevated controls, modals/pickers and focused surfaces.
- **Secondary Surface:** `#0D0D0D` — subtle secondary containers.
- **Border:** `#252525` — quiet separation without shadows.
- **Primary Text:** `#F7F7F7` — readable content.
- **Secondary Text:** `#999999` — metadata/supporting information.

### Original Stitch token set

The common Stitch export also contains this broader token vocabulary. It is preserved here rather than replaced with a generic theme:

```yaml
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1c1c'
  surface-container: '#1f2020'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e4e2e1'
  on-surface-variant: '#c2caad'
  inverse-surface: '#e4e2e1'
  inverse-on-surface: '#303030'
  outline: '#8c9479'
  outline-variant: '#424a33'
  surface-tint: '#9bd900'
  primary: '#ffffff'
  on-primary: '#243600'
  primary-container: '#b1f800'
  on-primary-container: '#4d6e00'
  inverse-primary: '#486800'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#ffffff'
  on-tertiary: '#313030'
  tertiary-container: '#e5e2e1'
  on-tertiary-container: '#656464'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b1f800'
  primary-fixed-dim: '#9bd900'
  on-primary-fixed: '#131f00'
  on-primary-fixed-variant: '#354e00'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c9c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474646'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b1f800'
  primary-fixed-dim: '#9bd900'
  on-primary-fixed: '#131f00'
  on-primary-fixed-variant: '#354e00'
```

## Typography

- **Primary UI:** Hanken Grotesk.
- **Workout metrics:** Plus Jakarta Sans.
- Metrics are intentionally prominent for gym readability.
- Body text does not drop below 16px in the supplied system.
- Section labels use compact uppercase styling.

```yaml
typography:
  display-metrics:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  caption:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
```

## Layout & spacing

```yaml
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px

spacing:
  margin-x: 16px
  gutter: 12px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  touch-target-min: 44px
```

Recurring visual patterns:
- Mobile-first iPhone-style composition around a 390px viewport.
- 16px horizontal content margins.
- 12px gutters where appropriate.
- 20px card rounding in the visual system.
- 56px primary CTA height in supplied focused flows.
- No decorative drop shadows.
- Bottom navigation on normal dashboard/detail views; removed during focused workout/check-in flows.
- One dominant primary CTA when one action is expected.
- Lime is used surgically, not as general decoration.

## Component language

Reuse these established patterns instead of inventing alternatives:

- App/header shell
- Bottom navigation
- Primary CTA / sticky CTA
- Secondary actions
- Tonal cards
- Metric cards
- Exercise cards
- Exercise thumbnails
- Equipment tags
- Anatomical/muscle visualization
- Progress bars
- Status chips
- Segmented controls
- Large numeric inputs
- Set logger
- Rest timer
- Meal cards
- Meal-option cards
- Check-in response cards
- One-question onboarding screens
- Confirmation/completion states
- Coach Insight cards
- Schedule/rescheduling cards

## UX rules

- One-handed operation is a first-class requirement.
- Touch targets remain at least 44px.
- Gym flows must be immediately scannable.
- Do not overload workout screens with navigation or decoration.
- Use a single primary CTA for the main action.
- Preserve previous-session context when it supports progression.
- Use lime for action, completion, progression, active muscles and success.
- Use restrained neutrals for secondary information.
- Onboarding uses progressive disclosure and one primary question/decision at a time.
- Focused workout/check-in modes can hide bottom navigation.
- Recovery/rest states remain part of the same system while reducing visual intensity.

# Complete Stitch Screen Inventory

## 1. Core daily & workout experience

| Screen | Stitch title | Screenshot |
|---|---|---|
| `coachx_today` | COACHX - Today Dashboard | available |
| `coachx_calendar` | COACHX Calendar | available |
| `coachx_day_detail` | Day Detail - Saturday August 8 | available |
| `coachx_workout_overview` | Workout Overview - GLUTES + HAMSTRINGS | available |
| `coachx_active_log` | Active Exercise Log | available |
| `coachx_exercise_alternatives` | COACHX - Exercise Alternatives | available |
| `coachx_daily_nutrition` | COACHX - Nutrition Tracking | export placeholder (`<FIFE Image failed to fetch>`) |

## 2. Plan, recovery & workout adaptation

| Screen | Stitch title | Screenshot |
|---|---|---|
| `coachx_post_workout_summary` | COACHX - Workout Summary | available |
| `coachx_rest_day_today` | COACHX - Rest Day | available |
| `coachx_adjust_workout_initial` | Adjust Workout | available |
| `coachx_reschedule_shorter_session` | Adjust Workout - CoachX | available |
| `coachx_reschedule_reorganize_week` | CoachX - Reorganize Week | available |
| `coachx_schedule_updated` | CoachX - Schedule Updated | available |
| `coachx_plan_reveal` | CoachX - Your Plan is Ready | available |

## 3. Onboarding, baseline & plan construction

| Screen | Stitch title | Screenshot |
|---|---|---|
| `coachx_onboarding_intro` | COACHX - Onboarding | export placeholder (`<FIFE Image failed to fetch>`) |
| `coachx_profile_name` | COACHX - Onboarding - What should we call you? | available |
| `coachx_profile_metrics` | COACHX - Onboarding: Height & Weight | export placeholder (`<FIFE Image failed to fetch>`) |
| `coachx_goals_main_goal` | COACHX - Goal Selection | available |
| `coachx_goals_priorities` | COACHX - Goals | export placeholder (`<FIFE Image failed to fetch>`) |
| `coachx_training_experience_duration` | COACHX Onboarding | available |
| `coachx_training_experience_confidence` | COACHX - Onboarding | export placeholder (`<FIFE Image failed to fetch>`) |
| `coachx_training_experience_movements` | COACHX - Training Experience | export placeholder (`<FIFE Image failed to fetch>`) |
| `coachx_training_experience_loads` | COACHX Onboarding - Current Loads | available |
| `coachx_training_experience_summary` | COACHX - Training Profile Summary | available |
| `coachx_training_preferences_setup` | COACHX Onboarding - Training Preferences | export placeholder (`<FIFE Image failed to fetch>`) |
| `coachx_onboarding_schedule_lifestyle` | COACHX Onboarding - Schedule & Lifestyle | export placeholder (`<FIFE Image failed to fetch>`) |
| `coachx_onboarding_health_limitations` | COACHX - Health & Limitations | available |
| `coachx_onboarding_daily_nutrition_setup` | COACHX Onboarding - Nutrition | available |
| `coachx_baseline_intro` | COACHX - Baseline Intro | available |
| `coachx_baseline_measurements` | COACHX - Measurements | available |
| `coachx_baseline_photos` | COACHX - Progress Photos | available |
| `coachx_profile_final_review` | COACHX - Review Profile | available |
| `coachx_building_your_plan` | COACHX - Building Your Plan | available |

# Package structure

```text
COACHX_STITCH_MASTER/
├── DESIGN.md
├── screens/
│   ├── <screen-name>/
│   │   ├── code.html
│   │   └── screen.png
│   └── ...
└── assets/
    └── exercise_thumbnails/
        ├── hip_thrust.png
        └── romanian_deadlift.png
```

## Asset note

The two exercise demonstration images from the supplied Stitch exports are preserved under `assets/exercise_thumbnails/`.

Some Stitch screenshot exports are literal `<FIFE Image failed to fetch>` placeholders instead of valid PNG renders. Those files are preserved exactly as supplied. Their `code.html` remains available; regenerate their screenshot from Stitch when visual QA requires it.

## Codex implementation rule

When implementing a screen:

1. Open that screen's `code.html`.
2. Use its `screen.png` when it is a valid render.
3. Follow this `DESIGN.md` for shared tokens and system behavior.
4. Reuse the established COACHX component language.
5. Do not substitute a generic UI kit or invent a new visual language.
6. Do not silently alter colors, typography, spacing, radii, button treatment, iconography, navigation behavior or visual hierarchy.
7. If implementation and Stitch differ, reconcile against the Stitch reference.
8. Keep all supplied screens within one coherent COACHX system.

## Content note

This package consolidates **design artifacts**, not the final production data model. Demo names, dates, workout values and example copy inside individual Stitch screens are preserved exactly in their source exports and should be treated as visual examples until the application data layer is connected.

---

## Consolidation summary

- **33 Stitch screens consolidated**
- **33 `code.html` exports**
- **33 `screen.png` exports preserved**
- **2 exercise reference images preserved**
- **1 master `DESIGN.md`**
- Duplicate Stitch `DESIGN.md` files removed
- Screen exports kept intact and organized by screen
