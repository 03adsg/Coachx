---
name: COACHX — Master Stitch Design System
version: 2.0
date: 2026-08-08
source: Google Stitch exports consolidated into one implementation package
physical_screens: 51
new_since_v1: 18
---

# COACHX — Master Stitch Design System v2

This package is the **single consolidated visual reference** for the current COACHX athlete-side MVP Stitch exports.

It preserves every supplied physical Stitch `code.html` and `screen.png` and adds implementation guidance without replacing Stitch as the visual source of truth.

## Source-of-truth order

1. The matching **Stitch `screen.png` rendering** is the visual source of truth when valid.
2. The matching **Stitch `code.html`** is the structural/style source for that exact frame.
3. This `DESIGN.md` defines the shared COACHX system and the product-wide rules added after the first export.
4. `SCREEN_INDEX.md` maps every physical frame to its flow and suggested implementation route/state.
5. If a described flow has no physical export, **do not invent a final design**. See `EXPORT_GAPS.md`.

## Brand character

COACHX is a premium personal performance coaching product, not a generic workout tracker. The interaction loop is:

**TRAIN → TRACK → CHECK-IN → ADJUST**

The visual language is dark, athletic, controlled, highly legible, one-handed and deliberately restrained.

## Definitive palette

- **Deep Black** `#050505` — primary background.
- **Charcoal** `#1A1A1A` — meaningful section-level rhythm.
- **Card Surface** `#121212` — cards/content containers.
- **Elevated Surface** `#181818` — focused/elevated surfaces.
- **Secondary Surface** `#0D0D0D` — quiet secondary containers.
- **Primary Lime** `#B6FF00` — primary action, active/completed/progression states, active muscle groups.
- **Active Lime** `#CAFF4A` — optional active highlight where already established.
- **Primary Text** `#F7F7F7`.
- **Secondary Text** `#999999`.
- **Muted Text** `#666666`.
- **Border** `#252525`.
- **Warning** `#FFB020` — only for useful attention/review states.
- **Error** `#FF4D4F` — actual errors, not normal regression or body changes.

### Black / Charcoal rhythm

Charcoal is a **section-level grouping tool**, not zebra striping. Typical rhythm:

Deep Black hero/context → Charcoal information group → Deep Black primary work → Charcoal secondary/recovery context → Deep Black CTA.

Cards remain `#121212` where appropriate. Do not mechanically alternate every card or row.

## Typography

- Primary UI: **Hanken Grotesk**.
- Performance metrics may use **Plus Jakarta Sans** where the Stitch export already establishes it.
- Strong compact hierarchy; no gratuitous giant display type.
- Body text remains readable in gym conditions.
- Uppercase section labels are compact and disciplined.

## Layout

- iPhone-first; reference viewport approximately **390px portrait**.
- Horizontal page margin approximately **16px**.
- Minimum touch target **44px**.
- Primary CTA commonly ~56px where the focused flow uses it.
- Card radius approximately **20px**.
- Safe-area aware (`env(safe-area-inset-top/bottom)`).
- Normal navigation: **Today / Calendar / Progress / Profile**.
- Hide normal bottom nav in focused workout, check-in, capture or nested selection flows where Stitch does so.

## Motion / GSAP implementation rule

COACHX code uses a centralized GSAP motion layer.

- Screen enter: opacity + small `y` shift, roughly 0.25–0.45s.
- Cards: restrained stagger roughly 0.04–0.08s.
- Bottom sheets: controlled upward reveal.
- Prefer `transform` and `opacity`.
- Never block persistence or navigation on animation completion.
- Respect `prefers-reduced-motion`.
- No bounce-heavy, showreel or gamified motion.

**Motion serves UX. COACHX motion should feel expensive, not excessive.**

## Core interaction/data rules reflected by the designs

### Training
- Preserve set history: weight, reps and optional RIR.
- Show previous comparable performance on the next occurrence.
- Preserve programmed exercise vs actual performed exercise.
- Swaps should preserve movement intent; do not randomize key movements merely for variety.
- Completed sets must not be discarded during swaps, shortened sessions or pain/discomfort adaptations.

### Nutrition
- Athlete chooses from structured equivalent options; this is not a manual calorie-tracker UI.
- Keep allergy/restriction safety above preference/variety.
- Preferences are not prescription. Editing preferences must not silently rewrite calorie/macronutrient targets.

### Progress
- Treat weight as one signal, not the hero metric.
- No body score, transformation score, fitness age or attractiveness rating.
- Photo comparison is private/objective; no body reshaping, beauty filters or body-fat estimation from photos.
- Insights should synthesize structured data and avoid unsupported causal claims.

### Health / limitations
- Distinguish dislike, discomfort, limitation and injury.
- Do not diagnose.
- Important changes can trigger program/coach review instead of silent prescription changes.

### Program changes
Profile/preference update ≠ active program rewrite.

PROFILE CHANGE → IMPACT DETECTED → RECOMMENDATION → VALIDATION/REVIEW → PROGRAM CHANGE.

## Semantic anatomy rule

Anatomical imagery must match the actual programmed muscle focus. A `Glutes + Hamstrings` state must never display chest/shoulder anatomy merely as decoration. If the correct approved visual is unavailable, use a neutral semantic placeholder rather than an incorrect body map.

## Assets

The original exercise thumbnails remain under:

- `assets/exercise_thumbnails/hip_thrust.png`
- `assets/exercise_thumbnails/romanian_deadlift.png`

Do not replace them with random stock imagery when implementing the corresponding Stitch frames.

## Physical export status

This v2 contains **51 physical Stitch screen directories**, each with `code.html`; screenshots are preserved exactly as exported.

- Valid screenshots: **43**
- Stitch screenshot placeholders/fetch failures: **8**

For placeholder screenshots, the matching `code.html` remains the supplied physical Stitch reference. See `EXPORT_GAPS.md`.

## New physical screens added since Master v1

- `coachx_detailed_trends`
- `coachx_edit_health_limitations`
- `coachx_edit_training_preferences`
- `coachx_exercise_detail_hip_thrust`
- `coachx_exercise_library`
- `coachx_measurement_update_input`
- `coachx_measurement_update_success`
- `coachx_notifications_reminders`
- `coachx_pain_discomfort_assessment`
- `coachx_pain_discomfort_location`
- `coachx_pain_discomfort_resolution`
- `coachx_phase_review_week_8`
- `coachx_profile_preferences_index`
- `coachx_program_impact_review`
- `coachx_program_overview`
- `coachx_progress_photos_capture_front`
- `coachx_progress_photos_comparison`
- `coachx_progress_photos_entry`

## Companion documents

- `SCREEN_INDEX.md` — all physical screens, categories, title, screenshot state and suggested route/state.
- `IMPLEMENTATION_BATCHES.md` — Codex implementation order.
- `EXPORT_GAPS.md` — designed/referenced experiences that still lack a standalone physical export in the supplied ZIP files.
- `SOURCE_MANIFEST.md` — source ZIP provenance and hashes.
- `MANIFEST.json` — machine-readable file hashes/sizes.
- `sources/STITCH_ORIGINAL_DESIGN.md` — untouched common Stitch design document supplied with the exports.

## Final implementation principle

When a physical Stitch frame exists: **implement it, do not reinterpret it**.

When only a product flow has been described but no physical frame exists: preserve the data/route architecture, keep any existing implementation explicitly temporary, and wait for the missing export rather than fabricating a final visual design.
