# COACHX Stitch Screen Index v2

Physical exported screens: **51**.

> Suggested routes below are implementation guidance, not a replacement for the Stitch visual source. Nested flow states do not require their own URL.

## Core Daily & Workout

| Screen | Stitch title | Suggested route/state | Screenshot | Source |
|---|---|---|---|---|
| `coachx_today` | COACHX - Today Dashboard | `/ (Today state)` | available (487×1387) | `stitch_coachx_mobile_design_system.zip` |
| `coachx_calendar` | COACHX Calendar | `/calendar` | available (487×1075) | `stitch_coachx_mobile_design_system.zip` |
| `coachx_day_detail` | Day Detail - Saturday August 8 | `/day/[date]` | available (487×2287) | `stitch_coachx_mobile_design_system.zip` |
| `coachx_workout_overview` | Workout Overview - GLUTES + HAMSTRINGS | `/workout/[sessionId]` | available (487×2762) | `stitch_coachx_mobile_design_system.zip` |
| `coachx_active_log` | Active Exercise Log | `/workout/[sessionId]/exercise/[exerciseId]` | available (487×1412) | `stitch_coachx_mobile_design_system.zip` |
| `coachx_exercise_alternatives` | COACHX - Exercise Alternatives | `nested sheet/state in active workout` | available (487×2157) | `stitch_coachx_mobile_design_system.zip` |
| `coachx_daily_nutrition` | COACHX - Nutrition Tracking | `/day/[date]/nutrition` | export placeholder | `stitch_coachx_mobile_design_system.zip` |

## Workout Adaptation, Exercise & Safety

| Screen | Stitch title | Suggested route/state | Screenshot | Source |
|---|---|---|---|---|
| `coachx_post_workout_summary` | COACHX - Workout Summary | `/workout/[sessionId]/summary` | available (325×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_rest_day_today` | COACHX - Rest Day | `/ alternate Today state` | available (706×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_adjust_workout_initial` | Adjust Workout | `nested adjust-workout flow` | available (706×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_reschedule_shorter_session` | Adjust Workout - CoachX | `nested adjust-workout state` | available (706×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_reschedule_reorganize_week` | CoachX - Reorganize Week | `nested adjust-workout state` | available (637×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_schedule_updated` | CoachX - Schedule Updated | `adjust-workout success state` | available (706×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_exercise_library` | COACHX - Exercise Library | `/exercises` | available (536×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_exercise_detail_hip_thrust` | Exercise Detail - Hip Thrust | `/exercises/[exerciseId]` | available (251×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_pain_discomfort_assessment` | COACHX - Initial Assessment | `nested workout safety flow` | available (706×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_pain_discomfort_location` | COACHX - Adjust Session | `nested workout safety flow` | available (521×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_pain_discomfort_resolution` | COACHX - Adjust Session | `nested workout safety flow` | available (640×1600) | `stitch_coachx_mobile_design_system (4).zip` |

## Onboarding, Baseline & Plan Construction

| Screen | Stitch title | Suggested route/state | Screenshot | Source |
|---|---|---|---|---|
| `coachx_onboarding_intro` | COACHX - Onboarding | `/onboarding` | export placeholder | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_profile_name` | COACHX - Onboarding - What should we call you? | `/onboarding/profile` | available (487×927) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_profile_metrics` | COACHX - Onboarding: Height & Weight | `/onboarding/profile` | export placeholder | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_goals_main_goal` | COACHX - Goal Selection | `/onboarding/goals` | available (487×1918) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_goals_priorities` | COACHX - Goals | `/onboarding/goals` | export placeholder | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_duration` | COACHX Onboarding | `/onboarding/training-experience` | available (487×1003) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_confidence` | COACHX - Onboarding | `/onboarding/training-experience` | export placeholder | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_movements` | COACHX - Training Experience | `/onboarding/training-experience` | export placeholder | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_loads` | COACHX Onboarding - Current Loads | `/onboarding/training-experience` | available (487×1290) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_summary` | COACHX - Training Profile Summary | `/onboarding/training-experience` | available (487×1057) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_preferences_setup` | COACHX Onboarding - Training Preferences | `/onboarding/training-preferences` | export placeholder | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_onboarding_schedule_lifestyle` | COACHX Onboarding - Schedule & Lifestyle | `/onboarding/schedule` | export placeholder | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_onboarding_health_limitations` | COACHX - Health & Limitations | `/onboarding/health` | available (706×1600) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_onboarding_daily_nutrition_setup` | COACHX Onboarding - Nutrition | `/onboarding/nutrition` | available (706×1600) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_baseline_intro` | COACHX - Baseline Intro | `/onboarding/baseline` | available (706×1600) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_baseline_measurements` | COACHX - Measurements | `/onboarding/baseline` | available (569×1600) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_baseline_photos` | COACHX - Progress Photos | `/onboarding/baseline` | available (488×1600) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_profile_final_review` | COACHX - Review Profile | `/onboarding/review` | available (435×1600) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_building_your_plan` | COACHX - Building Your Plan | `/onboarding/building-plan` | available (706×1600) | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_plan_reveal` | CoachX - Your Plan is Ready | `/onboarding/plan-ready` | available (322×1600) | `stitch_coachx_mobile_design_system (4).zip` |

## Progress & Reviews

| Screen | Stitch title | Suggested route/state | Screenshot | Source |
|---|---|---|---|---|
| `coachx_measurement_update_input` | COACHX - Update Measurements | `/progress/measurements` | available (419×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_measurement_update_success` | COACHX - Measurement Success | `measurement success state` | available (706×1600) | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_progress_photos_entry` | Progress Photos | `/progress/photos` | available (627×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_progress_photos_capture_front` | COACHX - Progress Photos | `/progress/photos/capture (pose state)` | available (706×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_progress_photos_comparison` | COACHX - Compare Progress | `/progress/photos/compare` | available (461×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_detailed_trends` | COACHX - Detailed Trends | `/progress/trends` | available (396×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_phase_review_week_8` | COACHX Phase Review | `/progress/phase-review` | available (412×1600) | `stitch_coachx_mobile_design_system (5).zip` |

## Program, Profile & Settings

| Screen | Stitch title | Suggested route/state | Screenshot | Source |
|---|---|---|---|---|
| `coachx_program_overview` | COACHX - My Program | `/program` | available (405×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_notifications_reminders` | COACHX - Notifications & Reminders | `/profile/notifications` | available (706×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_profile_preferences_index` | Edit Profile & Preferences | `/profile/preferences` | available (706×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_edit_training_preferences` | Edit Training Preferences - COACHX | `/profile/preferences/training` | available (706×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_edit_health_limitations` | Edit Health & Limitations \| COACHX | `/profile/preferences/health` | available (706×1600) | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_program_impact_review` | Program Impact Review - COACHX | `profile-change impact review state` | available (706×1600) | `stitch_coachx_mobile_design_system (5).zip` |
