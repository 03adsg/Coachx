# COACHX — Physical Export Gaps

This file prevents Codex from confusing **a flow discussed/designed in the project** with **a physical Stitch frame actually present in the supplied ZIPs**.

## No standalone physical screen directory in the supplied exports

The following athlete-MVP experiences were discussed/designed in the project history but do **not** have their own physical `coachx_*/code.html + screen.png` directory in the ZIP exports consolidated here:

- **Welcome / Login**
- **Meal Options / equivalent-meal chooser**
- **Progress main dashboard**
- **Weekly Check-in**
- **Check-in Completion & Insights**
- **Profile & Settings main screen**

Do not treat a synthesized implementation of one of these as Stitch-approved merely because the flow is known.

## Representative-state exports (not every state is a separate frame)

These flows intentionally have only representative physical frames in this package:

- **Progress Photos:** entry, front capture, comparison. Side/back/review/success can reuse the same capture/review architecture rather than requiring unrelated visual systems.
- **Edit Profile & Preferences:** index, training preferences, health/limitations and program-impact review are exported. Goals/schedule/nutrition editors should reuse the established onboarding/editing component pattern rather than invent a new design language.
- **Pain & Discomfort:** three exported states cover assessment → location/context → resolution.
- **Measurement Update:** input + success states are exported.
- **Reschedule Workout:** initial, shorter-session, reorganize-week and success states are exported.

## Known Stitch screenshot fetch placeholders

The following physical screen directories have valid `code.html`, but their supplied `screen.png` is the literal Stitch export placeholder `<FIFE Image failed to fetch>`:

- `coachx_daily_nutrition`
- `coachx_goals_priorities`
- `coachx_onboarding_intro`
- `coachx_onboarding_schedule_lifestyle`
- `coachx_profile_metrics`
- `coachx_training_experience_confidence`
- `coachx_training_experience_movements`
- `coachx_training_preferences_setup`

Use the supplied `code.html` as the available Stitch reference. Do not silently replace these frames with unrelated generic UI.

## Intentionally outside the frozen athlete MVP

These are not missing exports; they were intentionally deferred:

- Apple Health / Apple Watch / Connect Services
- Detailed Strength Analytics
- Coach-facing Dashboard / Coach Panel
- Program history deep-dive
- Shopping list / meal-prep planner
- Exportable progress report

Do not expand into these during athlete-MVP implementation unless explicitly requested.
