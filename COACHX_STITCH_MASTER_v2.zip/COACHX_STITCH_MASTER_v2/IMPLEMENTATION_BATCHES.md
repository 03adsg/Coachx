# COACHX — Stitch Implementation Batches

The purpose of batching is to keep Codex implementation coherent and visually auditable. Each batch should follow:

**Architecture/TypeScript → Frontend/Stitch → Visual QA → QA/Testing**

All batches preserve centralized design tokens, semantic anatomy mapping, GSAP motion, safe areas and a typed mock/data-service boundary until production services are connected.

## Existing Phase 1 foundation — preserve and refine

Already implemented in the current development branch before this v2 package:

- Today
- Calendar
- Day Detail
- Progress (temporary until a physical Progress export is supplied)
- Profile
- Shared shell / bottom navigation
- GSAP motion layer
- iPhone/PWA foundation

Do not rebuild these blindly. Reconcile them against physical Stitch frames where present.

## Batch A — Core Workout + Exercise Safety

Implement in this order:

1. `coachx_workout_overview`
2. `coachx_active_log`
3. `coachx_exercise_alternatives`
4. `coachx_post_workout_summary`
5. `coachx_adjust_workout_initial`
6. `coachx_reschedule_shorter_session`
7. `coachx_reschedule_reorganize_week`
8. `coachx_schedule_updated`
9. `coachx_exercise_library`
10. `coachx_exercise_detail_hip_thrust`
11. `coachx_pain_discomfort_assessment`
12. `coachx_pain_discomfort_location`
13. `coachx_pain_discomfort_resolution`
14. `coachx_rest_day_today`

Critical rules: preserve completed sets, prescribed-vs-performed exercise identity, last comparable performance and semantic muscle/anatomy mapping.

## Batch B — Nutrition

Physical export available:

1. `coachx_daily_nutrition`

The dedicated Meal Options physical frame is not present in the supplied ZIPs. Do not declare a final Stitch match for that screen until the export exists. Its route/data contract may be prepared without fabricating final UI.

## Batch C — Progress + Reviews

1. Keep current `/progress` explicitly temporary until its physical Stitch export is supplied.
2. `coachx_measurement_update_input`
3. `coachx_measurement_update_success`
4. `coachx_progress_photos_entry`
5. `coachx_progress_photos_capture_front`
6. `coachx_progress_photos_comparison`
7. `coachx_detailed_trends`
8. `coachx_phase_review_week_8`

Weekly Check-in and Check-in Completion/Insights are known product flows but have no standalone physical export in this package. Do not fabricate final Stitch fidelity.

## Batch D — Onboarding + Program

1. `coachx_onboarding_intro`
2. `coachx_profile_name`
3. `coachx_profile_metrics`
4. `coachx_goals_main_goal`
5. `coachx_goals_priorities`
6. Training Experience sequence
7. `coachx_training_preferences_setup`
8. `coachx_onboarding_schedule_lifestyle`
9. `coachx_onboarding_health_limitations`
10. `coachx_onboarding_daily_nutrition_setup`
11. Baseline intro / measurements / photos
12. `coachx_profile_final_review`
13. `coachx_building_your_plan`
14. `coachx_plan_reveal`
15. `coachx_program_overview`

Welcome/Login is not physically exported in the supplied packages; keep authentication UI provisional until that reference is available.

## Batch E — Profile Editing + Notifications + Cross-flow QA

1. `coachx_profile_preferences_index`
2. `coachx_edit_training_preferences`
3. `coachx_edit_health_limitations`
4. `coachx_program_impact_review`
5. `coachx_notifications_reminders`
6. Cross-flow navigation audit
7. 375 / 390 / 430px visual QA
8. PWA standalone QA
9. Reduced-motion QA
10. Error/loading/empty/offline state QA

## After visual MVP implementation

Only after the athlete-side visual MVP is stable:

1. Supabase schema + Auth + RLS + Storage
2. Replace fixtures behind typed service boundaries
3. Workout/session persistence
4. Progress-photo private storage and signed access
5. Notification infrastructure
6. OpenAI Coach Engine using validated structured outputs
7. Coach review workflow

OpenAI is never the persistent source of truth and must remain server-side.
