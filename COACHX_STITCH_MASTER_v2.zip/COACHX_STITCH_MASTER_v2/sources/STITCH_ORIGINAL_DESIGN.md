---
name: High-Performance Athletic System
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1c1c'
  surface-container: '#1f2020'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e4e2e1'
  on-surface-variant: '#c2caad'
  inverse-surface: '#e4e2e1'
  inverse-on-surface: '#303030'
  outline: '#8c9479'
  outline-variant: '#424a33'
  surface-tint: '#9bd900'
  primary: '#ffffff'
  on-primary: '#243600'
  primary-container: '#b1f800'
  on-primary-container: '#4d6e00'
  inverse-primary: '#486800'
  secondary: '#c6c6c7'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b4b5b5'
  tertiary: '#ffffff'
  on-tertiary: '#313030'
  tertiary-container: '#e5e2e1'
  on-tertiary-container: '#656464'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b1f800'
  primary-fixed-dim: '#9bd900'
  on-primary-fixed: '#131f00'
  on-primary-fixed-variant: '#354e00'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c9c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474646'
  background: '#131313'
  on-background: '#e4e2e1'
  surface-variant: '#353535'
typography:
  display-metrics:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  caption:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-x: 16px
  gutter: 12px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  touch-target-min: 44px
---

## Brand & Style

The design system is engineered for a high-performance personal training and nutrition environment. It targets serious athletes and fitness enthusiasts who demand precision, clarity, and a professional edge. 

The aesthetic is **Dark-Mode Minimalist** with **Tactile Athleticism**, heavily inspired by top-tier performance tracking hardware. It utilizes a deep black foundation to reduce eye strain during early morning or late-night workouts, paired with high-energy fluorescent accents that signify action and achievement. The interface prioritizes one-handed usability and large touch targets to ensure the UI remains functional even during intense physical exertion.

Key characteristics:
- **Athletic Precision:** Use of rigid grids and high-contrast typography.
- **Elite Professionalism:** Avoidance of decorative shadows in favor of tonal layering.
- **Immediate Feedback:** Fluorescent lime green acts as the primary driver for all successful interactions and active states.

## Colors

This design system uses a strictly hierarchical dark palette to establish depth without the need for drop shadows. 

- **The Deep Black (#050505)** is the ground layer, used for the main application background.
- **The Primary Accent (#B6FF00)** is reserved strictly for "active" states: completed sets, active muscle groups, primary CTAs, and success indicators.
- **Tonal Layers:** Surfaces move from `#0D0D0D` (secondary containers) to `#121212` (cards) and `#181818` (elevated modals/pickers) to guide the user's focus toward interactive content.
- **Text Contrast:** Ensure `#F7F7F7` is used for all readable content, while `#999999` handles metadata and secondary information to maintain a clean visual hierarchy.

## Typography

The typography system is built on **Hanken Grotesk** for its modern, neo-grotesque clarity that mirrors the SF Pro aesthetic but with a slightly more athletic, sharp edge. For workout metrics (reps, weight, timers), **Plus Jakarta Sans** is used in a bold, condensed-style weight to maximize readability during motion.

- **Metrics:** Should always be prominent. Use `display-metrics` for active workout values.
- **Hierarchy:** Use `label-caps` for section headers (e.g., "TARGET MUSCLES") to create a structured, professional look.
- **Readability:** Body text never drops below 16px to ensure accessibility in a gym environment where the phone may be at arm's length.

## Layout & Spacing

This design system utilizes a **Mobile-First Fixed Grid** logic optimized for a 390px width.

- **Horizontal Margins:** A consistent 16px margin on left and right edges.
- **Vertical Rhythm:** Content blocks are separated by 24px increments. Internal card spacing should follow a 16px rhythm.
- **Bottom Navigation:** A persistent bar housing four key destinations (Today, Calendar, Progress, Profile). Icons must have a clear active state using the Primary Accent color.
- **One-Handed Zone:** All primary action buttons (Start Workout, Log Set) must be placed within the bottom 40% of the screen.

## Elevation & Depth

This system avoids the use of drop shadows to maintain a sleek, high-tech aesthetic. Depth is achieved purely through **Tonal Layering** and **1px Borders**.

- **Level 0 (Background):** #050505.
- **Level 1 (In-flow Cards):** #121212 with a 1px border of #252525.
- **Level 2 (Overlays/Modals):** #181818 with a 1px border of #252525.
- **Contrast Rule:** Elements do not "float"; they are "staged" on top of darker backgrounds. When a card is active or pressed, the border color may transition to the Primary Accent (#B6FF00) to indicate focus.

## Shapes

The shape language is sophisticated and modern, using generous rounded corners to balance the aggressive black-and-lime color scheme.

- **Cards:** Use a 20px radius to create a soft, premium container.
- **Buttons:** Use a 16px radius. Primary buttons are large and blocky, filling the width of the screen (minus margins).
- **Inputs:** Use a 14px radius to distinguish them slightly from primary action buttons.
- **Muscle Visualization:** Anatomical maps should use organic, fluid shapes for muscle groups, with lime green signifying the "Target" muscle and a muted graphite (#252525) for inactive areas.

## Components

- **Primary Button:** High-contrast #B6FF00 background with #050505 text. 16px radius, minimum 56px height for easy tapping during workouts.
- **Secondary Button:** Ghost style with #252525 border and #F7F7F7 text.
- **Metric Card:** #121212 background, featuring `display-metrics` for the value and `label-caps` for the unit (e.g., 85 KG).
- **Workout List Item:** 1px border bottom (#252525). Includes a lead icon (exercise thumbnail) and a trailing chevron for navigation.
- **Status Chips:** Small, pill-shaped (#B6FF00 at 10% opacity) with #B6FF00 text to denote "Completed" or "Personal Best."
- **Progress Bar:** Background #252525, fill #B6FF00. Height of 8px with fully rounded ends.
- **Input Fields:** #0D0D0D background, 1px border (#252525), 14px radius. Active state transitions border to #B6FF00.