# COACHX — Source Manifest

The v2 package was consolidated from the original master plus the five available Stitch export ZIPs. Later exports are authoritative for duplicate physical frames; duplicate files were verified as unchanged where they overlap.

| Source | SHA-256 |
|---|---|
| `COACHX_STITCH_MASTER.zip` | `001825a659ad959495960130e43a1a4616f126ba82e4df4aa8d93e8ae925e04b` |
| `stitch_coachx_mobile_design_system.zip` | `e5691e495a241f101b28164069449deecdf1c02200f3d4cb45561abaea81f35c` |
| `stitch_coachx_mobile_design_system (2).zip` | `8df7f7025ae13a8e1c71c91118c858cdf0ae71627c4623513d89cee637aa2dce` |
| `stitch_coachx_mobile_design_system (3).zip` | `e5b0d4d89f1fea2f337e161535d17081b0a9969ff506211b328df38b340d8641` |
| `stitch_coachx_mobile_design_system (4).zip` | `90a5ca29393c2c24c6fb73f3f94ab871c06dbbd263667d39a55e76a2300b851c` |
| `stitch_coachx_mobile_design_system (5).zip` | `5e9fbc098ce64e546af2d9937855af7ec767ed7b85146dc08342d7eb4340a9dc` |

## Screen provenance

| Screen | Last supplied export |
|---|---|
| `coachx_active_log` | `stitch_coachx_mobile_design_system.zip` |
| `coachx_adjust_workout_initial` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_baseline_intro` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_baseline_measurements` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_baseline_photos` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_building_your_plan` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_calendar` | `stitch_coachx_mobile_design_system.zip` |
| `coachx_daily_nutrition` | `stitch_coachx_mobile_design_system.zip` |
| `coachx_day_detail` | `stitch_coachx_mobile_design_system.zip` |
| `coachx_detailed_trends` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_edit_health_limitations` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_edit_training_preferences` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_exercise_alternatives` | `stitch_coachx_mobile_design_system.zip` |
| `coachx_exercise_detail_hip_thrust` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_exercise_library` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_goals_main_goal` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_goals_priorities` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_measurement_update_input` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_measurement_update_success` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_notifications_reminders` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_onboarding_daily_nutrition_setup` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_onboarding_health_limitations` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_onboarding_intro` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_onboarding_schedule_lifestyle` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_pain_discomfort_assessment` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_pain_discomfort_location` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_pain_discomfort_resolution` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_phase_review_week_8` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_plan_reveal` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_post_workout_summary` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_profile_final_review` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_profile_metrics` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_profile_name` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_profile_preferences_index` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_program_impact_review` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_program_overview` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_progress_photos_capture_front` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_progress_photos_comparison` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_progress_photos_entry` | `stitch_coachx_mobile_design_system (5).zip` |
| `coachx_reschedule_reorganize_week` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_reschedule_shorter_session` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_rest_day_today` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_schedule_updated` | `stitch_coachx_mobile_design_system (4).zip` |
| `coachx_today` | `stitch_coachx_mobile_design_system.zip` |
| `coachx_training_experience_confidence` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_duration` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_loads` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_movements` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_experience_summary` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_training_preferences_setup` | `stitch_coachx_mobile_design_system (2).zip` |
| `coachx_workout_overview` | `stitch_coachx_mobile_design_system.zip` |